## SimpleBleScanner
This is a simple BLE scanner for Android.
It asks for the required permissions and scans for BLE devices for 5 seconds.

It displays the address of the devices found.
